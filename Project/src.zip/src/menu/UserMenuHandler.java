package menu;

import document.service.DocumentManager;
import exceptions.DocumentCreationException;
import exceptions.UserCreationException;
import document.model.Document;
import document.model.DocumentType;
import document.model.DocumentVersion;
import document.service.DocumentService;
import manager.UserManager;
import model.*;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserMenuHandler {
    private final UserManager userManager;

    private DocumentService documentService = new DocumentService();
    private static final Logger logger = Logger.getLogger(UserMenuHandler.class.getName());


    public UserMenuHandler(UserManager userManager)
    {
        this.userManager = userManager;
    }



    public void startMenu(Scanner sc, PrintStream out) {
        showUserMenu(sc, out);
    }

    private void showUserMenu(Scanner sc, PrintStream out){
        while (true)
        {
            out.println("Login? Y/N");
            String login = sc.nextLine();

            if (!login.equalsIgnoreCase("Y"))
            {
                out.println("Goodbye.");
                return;
            }

            out.println("Enter username:");
            String userName = sc.nextLine();

            out.println("Enter password:");
            String password = sc.nextLine();

            User user = userManager.login(userName, password);

            if (user == null)
            {
                out.println("Error: Invalid login.");
                continue;
            }

            switch (user.getUserRole())
            {
                case ADMINISTRATOR:
                {
                    adminMenu(sc, out, user);
                    break;
                }
                case AUTHOR:
                {
                    authorMenu(sc, out, user);
                    break;
                }
                case REVIEWER:
                {
                    reviewerMenu(sc, out, user);
                    break;
                }
                case READER:
                {
                    readerMenu(sc, out, user);
                    break;
                }
            }
        }
    }

    private void readerMenu(Scanner sc, PrintStream out, User user) {
        out.println("Logged in as reader!");
    }

    private void reviewerMenu(Scanner sc, PrintStream out, User user) {
        out.println("Logged in as reviewer!");
    }






    private void adminMenu(Scanner sc, PrintStream out, User admin)
    {
        out.println("Logged in as admin.");
        out.println("Choose what action you want to take: " + Arrays.toString(userManager.getAdminActions().toArray()));



        if(sc.nextLine().equalsIgnoreCase("CREATE_USER")) {
            out.println("Enter user type to create: " + Arrays.toString(Role.values()) + ";");
            try {
                Role role = Role.valueOf(sc.nextLine().toUpperCase());

                out.println("Enter username:");
                String userName = sc.nextLine();

                out.println("Enter password:");
                String password = sc.nextLine();

                userManager.registerUser(userName, password, role);

                out.println("Success.");
            } catch (IllegalArgumentException e) {
                out.println("Error: Invalid user type.");
            } catch (UserCreationException e) {
                throw new RuntimeException(e);
            }
        }
    }


    private void authorMenu(Scanner sc, PrintStream out, User author) {
        out.println("Logged in as author.");
//        out.println("Choose what action you want to take: " + Arrays.toString(userManager.getAuthorActions().toArray()));
//
//        if(sc.nextLine().equalsIgnoreCase("L")) { //LIST_DOCUMENTS
//            out.print("Choose which of the following documents you want to view!");
//            try {
//                System.out.println(documentService.getDocuments());
//                List<Document> documentsList =  documentService.getDocuments();
//                //out.println(documentsList);
//                for(Document document : documentsList) {sype.");
//            }
//        }

        System.out.println("\nEntered as author!\n");
        while (true) {
            try {
                System.out.println("Waiting for request...");

                String request = readRequest(sc);

                if (request == null || request.isEmpty()) {
                    System.out.println("Client disconnected.");
                    break;
                }
                else if (request.equals("exit"))
                {
                    out.println("Goodbye!");
                    break;
                }

                String[] lines = request.split("\n");
                String command = lines[0];

                System.out.println("\nThe command is -> " + command + "\n");

                switch (command) {

                    case "CREATE_DOCUMENT" -> { //#1
                        String title = lines[1];
                        String description = lines[2];
                        String documentType = lines[3];
                        int authorId = author.getUserId();
                        try {

                            documentService.createDocument(title, description, authorId, DocumentType.valueOf(documentType));
                            sendResponse(out, "Document created!");
                        } catch (DocumentCreationException e ){
                            String content = "Cannot create document! Invalid data!";
                            sendResponse(out, content);
                        }
                    }

                    case "CREATE_VERSION" -> { //#2
                        int docId = Integer.parseInt(lines[1]);
                        String content = lines[2];
                        int authorId = author.getUserId();

                        documentService.addVersionToDocument(docId, content, authorId);

                        sendResponse(out, "OK", "Version created!");
                    }

                    case "LIST_DOCUMENTS" -> { //#3
                        List<Document> docs = documentService.getAllDocuments();

                        List<String> response = new ArrayList<>();
                        for (Document document : docs) {
                            response.add(document.getId() + " - " + document.getTitle());
                        }

                        sendResponse(out, response.toArray(new String[0]));
                    }


                    case "VIEW_VERSIONS" -> { // view the documents info only, maybe should rename to LIST_VERSIONS?
                        int docId = Integer.parseInt(lines[1]);
                        try {
                            List<DocumentVersion> versions = documentService.getVersions(docId);

                            List<String> response = new ArrayList<>();

                            for (DocumentVersion v : versions) {

                                response.add("Version " + v.getVersionNumber() + " - " + v.getStatus());
                            }

                            sendResponse(out, response.toArray(new String[0]));
                        } catch (NullPointerException e) {
                            String content = "Document does not exist!";
                            sendResponse(out, content);
                        }
                    }

                    case "VIEW_DRAFT" -> { //#5
                        int docId = Integer.parseInt(lines[1]);
                        int versionNumber = Integer.parseInt(lines[2]);
//                        if(lines[3] != null){
//                            int versionNumber2 = Integer.parseInt(lines[3]);
//                            String[] content = documentService.getDraftContentForTwoVersions(docId, versionNumber, versionNumber2);
//                            sendResponse(out, content);
//                        }
//                        else{
//                            String content = documentService.getDraftContent(docId, versionNumber);
//                            sendResponse(out, content);
//                        }
                        try {
                            String content = documentService.getDraftContent(docId, versionNumber);
                            if (content == null){
                                content = "Document/Version does not exist!";
                            }
                            sendResponse(out, content);
                        } catch (NullPointerException e) {
                            String content = "Document does not exist!2";
                            sendResponse(out, content);
                        }

                    }
                    case "EDIT_DRAFT" -> { //#6
                        int docId = Integer.parseInt(lines[1]);
                        int versionNumber = Integer.parseInt(lines[2]);
                        String newContent = lines[3];
                        int authorId = author.getUserId();
                        try{
                            String content = documentService.editDraftDocument(docId, versionNumber, newContent, authorId);
                            sendResponse(out, content);

                        } catch (NullPointerException e) {
                            String content = "Document does not exist!2";
                            sendResponse(out, content);
                        }
                    }
                    case "COMPARE_VERSIONS" -> { //#7
                        int docId = Integer.parseInt(lines[1]);
                        int versionNumber = Integer.parseInt(lines[2]);
                        int versionNumber2 = Integer.parseInt(lines[3]);
                        String[] contentArr = null;
                        try {
                            contentArr = documentService.getDraftContentForTwoVersions(docId, versionNumber, versionNumber2);
                            String content = null;
                            if (contentArr != null) {
                                content = contentArr[0] + "##TWO_VERSIONS###" + contentArr[1];
                                System.out.println("This is the content -> " + content);
                            }
                            if(contentArr[1] == null)
                            {
                                content = "One or more of the version numbers do not exist!";
                            }
                            System.out.println(content);
                            sendResponse(out, content);
                        } catch (IllegalArgumentException e) {
                            System.out.println("Error: Invalid version number!");
                            String content = "One or more of the version numbers do not exist!";
                            sendResponse(out, content);
                        } catch (NullPointerException e){
                            logger.log(Level.SEVERE, "Error occurred while loading documents", e);
                            String content = "One or more of the version numbers do not exist!";
                            sendResponse(out, content);
                        }
                    }


                    case "LIST_DRAFTS" -> {
                        int docId = Integer.parseInt(lines[1]);
                        try {
                            List<DocumentVersion> versions = documentService.getAllDraftDocuments(docId);
                            System.out.println(versions);
                            List<String> response = new ArrayList<>();
                            for (DocumentVersion version : versions) {
                                response.add(version.getContent() + " - " + version.getStatus());
                            }
                            sendResponse(out, response.toArray(new String[0]));
                        } catch (NullPointerException e) {
                            String content = "Document has no versions!";
                            sendResponse(out, content);
                        }

                    }

                    case "VIEW_DOCUMENT_HISTORY" -> {
                        int docId = Integer.parseInt(lines[1]);
                        ArrayList<DocumentVersion> versions = new ArrayList<>();
                        versions = documentService.getVersions(docId);
                        String[] contentArr = new String[versions.size()];
                        for (DocumentVersion version : versions) {
                            contentArr[i] = version.getAuthorId() + "\n" + version.getCreatedAt().toString() + "\n" + version.getStatus();
                        }
                    }
                    case "REQUEST_DOCUMENT_TYPES" -> {
                        List<String> documentTypes = documentService.getDocumentTypes();
                        sendResponse(out, documentTypes.toArray(new String[0]));
                    }


                    case "EXIT" -> {
                        System.out.println("Client requested exit.");
                        out.println("You requested to exit. Goodbye!");
                        break;
                    }

                    default -> {
                        sendResponse(out, "ERROR", "Unknown command");
                    }
                }

            } catch (Exception e) {
                System.out.println("Error occurred: " + e.getMessage());
                break;
            }
        }
    }


    public static String readRequest(Scanner sc) {
        StringBuilder request = new StringBuilder();
        String line;

        while (!(line = sc.nextLine()).equals("END")) {
            request.append(line).append("\n");
        }

        return request.toString();
    }
    public static void sendResponse(PrintStream out, String... lines) {
        for (String line : lines) {
            out.println(line);
        }
        out.println("END");
    }


    /*public static void sendCommand(PrintStream out, String command) {
        out.println(command);
        out.println("END");
    }
    public static String readResponse(Scanner sc) {

        StringBuilder sb = new StringBuilder();
        String line;

        while (!(line = sc.nextLine()).equals("END")) {
            sb.append(line).append("\n");
        }

        return sb.toString();
    }*/


}
