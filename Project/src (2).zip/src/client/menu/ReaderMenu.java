package client.menu;

import client.ui.LanternaEditor;
import document.service.DocumentService;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import static client.menu.ClientUserMenuService.readResponse;
import static client.menu.ClientUserMenuService.sendCommand;

public class ReaderMenu {

    private static final Logger logger = Logger.getLogger(ReaderMenu.class.getName());

    public static void showReaderMenu(Scanner console, Scanner sc, PrintStream out) {

        while (true) {
            System.out.println("""
                --- Reader Menu ---
                1. List Active Documents
                2. View Document (active version)
                0. Exit
                """);

            int choice;

            try {
                choice = Integer.parseInt(console.nextLine().trim());
            } catch (NumberFormatException ex) {
                logger.log(Level.WARNING, "Invalid number!");
                continue;
            }

            switch (choice) {

                case 1 -> { //LIST_ACTIVE_DOCUMENTS
                    sendCommand(out, "LIST_ACTIVE_DOCUMENTS");
                    System.out.println(readResponse(sc));
                }

                case 2 -> { // VIEW_DOCUMENT
                    System.out.print("Document ID: ");
                    String docId = console.nextLine().trim();

                    sendCommand(out, "VIEW_DOCUMENT", docId);
                    String content = readResponse(sc);

                    if (content.startsWith("Error")) {
                        System.out.println(content);
                    } else {
                        LanternaEditor viewer = new LanternaEditor(content); //only view
                        try {
                            viewer.startView();
                        } catch (IOException e) {
                            logger.log(Level.SEVERE, "Could not start Lanterna editor/viewer!", e);

                            System.out.println(content);
                        }
                    }
                }

                case 0 -> { //EXIT
                    sendCommand(out, "EXIT");
                    readResponse(sc);
                    System.out.println("Logged out from reader menu.");
                    return;
                }

                default -> System.out.println("Invalid choice. Please enter a number from the menu.");
            }
        }
    }

}
